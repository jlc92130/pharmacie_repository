class Client:
    
    def __init__(self,surname,name):
        self.surname = surname
        self.name = name
        self.date_achat = date_achat # format date 10/02/2017
