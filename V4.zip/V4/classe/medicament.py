
class Medicament:

    def __init__(self, name, price = None, quantity = None):
        self.name = name
        self.price = price
        self.quantity = quantity
